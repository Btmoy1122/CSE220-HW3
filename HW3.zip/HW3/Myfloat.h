#ifndef MYFLOAT_H
#define MYFLOAT_H

float construct_float_sf(char sign_bit, char exponent, unsigned int fraction);

#endif
