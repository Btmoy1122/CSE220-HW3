#ifndef MY_INTEGERS_H
#define MY_INTEGERS_H

void repr_convert(char source_repr, char target_repr, unsigned int repr);

#endif
